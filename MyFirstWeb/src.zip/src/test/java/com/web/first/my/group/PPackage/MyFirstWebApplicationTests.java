package com.web.first.my.group.PPackage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstWebApplicationTests {

	@Test
	void contextLoads() {
	}

}

