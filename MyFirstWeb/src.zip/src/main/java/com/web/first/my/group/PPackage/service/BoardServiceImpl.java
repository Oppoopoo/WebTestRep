package com.web.first.my.group.PPackage.service;

import com.web.first.my.group.PPackage.dto.BoardDto;
import com.web.first.my.group.PPackage.mapper.dao.BoardMapperDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service    //①
public class BoardServiceImpl implements BoardService {

    @Autowired
    private BoardMapper boardMapper;    //②

    @Override
    public List<BoardDto> selectBoardList() throws Exception {
        return boardMapper.selectBoardList();   //③
    }
}