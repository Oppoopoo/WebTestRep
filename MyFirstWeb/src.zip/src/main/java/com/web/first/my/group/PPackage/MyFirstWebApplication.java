package com.web.first.my.group.PPackage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstWebApplication.class, args);
	}

}
