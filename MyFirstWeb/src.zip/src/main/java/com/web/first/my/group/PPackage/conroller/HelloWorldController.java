package com.web.first.my.group.PPackage.conroller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController  //해당 클래스가 REST 컨트롤러 기능을 수행하도록 한다.
public class HelloWorldController {

    @RequestMapping("/")  //해당 메서드를 실행할 수 있는 주소를 설정한다. 여기서는 애플리케이션의 기본 주소를 /로 지정했다.
    public String hello() {
        return "Hello Wo1rld!";
    }
}
