package com.web.first.my.group.PPackage.service;

import java.util.List;
import com.web.first.my.group.PPackage.dto.BoardDto;

public interface BoardService {

    List<BoardDto> selectBoardList() throws Exception;

}